package method;

public class base {

}
